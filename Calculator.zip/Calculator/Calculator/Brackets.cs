﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Brackets
    {
        public string Input { get; private set; }
        private Computation compute;
        
        public Brackets(string Value)
        {
            this.Input = Value;
            if (!matchingBraces()) throw new ArgumentException("The braces are not matching");
        }
        private bool matchingBraces()
        {
            int countOpenBrace = 0, countCloseBrace = 0;
            foreach (char i in Input)
            {
                if (i == '(') countOpenBrace++;
                if (i == ')') countCloseBrace++;
            }
            if (countOpenBrace == countCloseBrace) return true;
            return false;
        }
        private String EliminateBrackets() //Finds the first open bracket 
        {
            int Startindx = this.Input.IndexOf('(');
            int EndIndx = this.Input.IndexOf(')');
            int count = EndIndx - Startindx+1 ;
            string SubString = this.Input.Substring(Startindx, count);

            return SubString;
        }
        public String getEliminationOfBrackets
        {
            get { return this.EliminateBrackets(); }
        }
        private string ComputedString()
        {
            string SubstringWithoutBrackets = getEliminationOfBrackets.Replace("(", ""); //deletes the actual brackets from the string: '(' && ')'
            SubstringWithoutBrackets = SubstringWithoutBrackets.Replace(")", "");
            compute = new Computation(SubstringWithoutBrackets);
            return compute.ToString();
        }
        public string OutputStringWithBraces()
        {
            string counter = "(" + this.OutputString + ")";
            return counter;
        }
        public string OutputString 
        {
            get { return this.ComputedString(); }
        }
    }
}
