﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Computation
    {
        public string inputName { get; private set; }
        private char[] Operators = { '+', '-', '/', '*', '%','s' };
        private bool VarInfrontOfSqrt;
        private Brackets theBrackets;
        public Computation(String input)
        {
            theBrackets = new Brackets(input);
            if (input == "") throw new Exception("One cannot compute an empty String");
            if (input.Contains(',')) input = input.Replace(',', '.');
            if (input.Contains("Sqrt"))
            {

                inputName = input.Replace("Sqrt", "s");
                return;
            }
            inputName = input;
           
        }
        private int[] indexesOfFactorialSubstring(string value)
        {
            List<int> indxplaces = new List<int>(); //Finds all the indexes of the Factorial sign and its numbers to compute factorial.
            if (value.Contains('!'))
            {

            int indexEnd= value.IndexOf('!'),  indexStart = 0;
            char t = ' ';
            int count = 0;
            int i;
            for (i = indexEnd - 1; i >= 0; i--)
            {
                t = value[i];
                if (char.IsDigit(t)) count++;
                else break;
            }
            indexStart = indexEnd - count;
            //10!
            indxplaces.Add(indexStart);
            indxplaces.Add(count);
            }
            return indxplaces.ToArray();

        }
        private int Factorial( int Number)
        {

            if (Number >=1) return Number * Factorial(Number - 1);

            else return 1;
        }
        private int Factorial(string input)
        {
            string Extractedstring = ExtractedFacString(input);
            int fac = Factorial(Convert.ToInt32(Extractedstring));
            return fac;
        }
        private string ExtractedFacString(string input)
        {
            int[] indicies = indexesOfFactorialSubstring(input);
            string temp = input.Substring(indicies[0], indicies[1]);
            return temp;
        }
        private double[] ExtractAndConvert(String input)
        {
            String[] ValuesWithoutOperators = input.Split(Operators,StringSplitOptions.RemoveEmptyEntries);
            double tempValueHolder = 0;
            Double[] realValues = new double[ValuesWithoutOperators.Length];
            int count = 0;

            string implicationException = "";
            foreach (string I in ValuesWithoutOperators)
            {
               
                if (I.Contains(','))
                { 

                   implicationException = I.Replace(',', '.');
                   tempValueHolder = Double.Parse(implicationException, System.Globalization.CultureInfo.InvariantCulture); 
                }
                else
                    tempValueHolder = Double.Parse(I, System.Globalization.CultureInfo.InvariantCulture);
                realValues[count] = tempValueHolder;
                count++;
            }
            return realValues;
        }
        private int[] indexOfSqrts(string value)
        {
            List<int> values = new List<int>();
            int startOfSubString = value.IndexOf('s'); // This method gets the first occurance of s and returns the indexes from there till the end of that string
            int count = 0;
            char test = ' ';
            for (int i = startOfSubString+1; i < value.Length; i++)
            {
                test = value[i];
                if (char.IsDigit(test) || test == '.' || test ==',') count++;
                else break;
            }
            values.Add(startOfSubString);
            values.Add(count);
            return values.ToArray();
        }
 
        private double extractSqrt(string value)  // Method extracts the string value of the sqrt and converts it to a double.
        {
            double hold = 0;
            double output = 0;
            string tempSubstring = "";
            int[] indices = indexOfSqrts(value); // gets the length(indexes) of all the sqrt in the given string. then extracts and computes it

             char i= ' ';
            if(indices[0]> 0) i= value[indices[0] - 1];

            if (char.IsDigit(i))
            {
                output = Double.Parse(i.ToString());
                VarInfrontOfSqrt = true;
            }

            tempSubstring = value.Substring(indices[0]+1, indices[1]);
       
            double sqrt = Double.Parse(tempSubstring, System.Globalization.CultureInfo.InvariantCulture);
            hold = Math.Sqrt(sqrt);
            if (VarInfrontOfSqrt) hold *= output;
            if (hold.ToString().Length >= 6)
            {
                tempSubstring = hold.ToString().Substring(0, 9);
                hold = Double.Parse(tempSubstring);
            }
            return hold;
        }
        private string RemoveStubSqrt(string Value) //this method removes the sqrt from the given string and computes it and return the value back.
        {
            string CopyOfsqrtData = "", ValueCopy = Value;
            while(ValueCopy.Contains('s'))
            if (ValueCopy.Contains('s'))
            {
                int[] indices = indexOfSqrts(ValueCopy);

                double sqrtVal = extractSqrt(ValueCopy);
                if (sqrtVal != 0)
                {
                    if (VarInfrontOfSqrt) //Test case for checking if there's a number infront of of the squareroot
                        CopyOfsqrtData = ValueCopy.Substring(indices[0] - 1, indices[1]);
                    else CopyOfsqrtData = ValueCopy.Substring(indices[0], indices[1] + 1);

                    ValueCopy = ValueCopy.Replace(CopyOfsqrtData, sqrtVal.ToString());
                    if (ValueCopy.Contains(',')) ValueCopy = ValueCopy.Replace(',', '.');
                }

            }
            return ValueCopy;

        }
        private string ExtractPi(string Value) //Extracts the Pi Value.
        {
            double hold = Math.PI;
            string ValueCopy = Value;
            if (Value.Contains("Pi"))
            {

                ValueCopy = Value.Replace("Pi", hold.ToString());
                if (ValueCopy.Contains(',')) ValueCopy = ValueCopy.Replace(',', '.');
            }
            return ValueCopy;
        }

        private List<char> Characters(string ValueCopy)
        {
            List<char> characters = new List<char>();
            foreach (char i in ValueCopy)
            {
                if (i == '.' || i == ',') continue;
                if (!char.IsDigit(i))
                {
                    characters.Add(i);
                }
            }
            return characters;
        }
        private double FinalOutputHelper(List<char> characters, double[] realValues)
        {
            double x = realValues[0];
            double y = 0;
            double returnValue = 0;
            int count = 0;
            for (int j = 0; j < realValues.Length; j++)
            {

                if (realValues.Length > 1)
                {
                    if (j == realValues.Length - 1) break;
                    y = realValues[j + 1];
                }
                char t = ' ';
                if (characters.Count >= 1)
                    t = characters[count];
                if (j == 0) returnValue = x;
                if (t == '+') returnValue += y;
                if (t == '-') returnValue -= y;
                if (t == '/') returnValue /= y;
                if (t == '*') returnValue *= y;

                count++;
            }

            return returnValue;
        }

        private string DoFactorialComputation(string Value)
        {
            int fac = 0;
            string replacefac = "";
            string ValueCopy = ExtractPi(Value);//Replaces PI with the actual value
            if (Value.Contains('!'))
            {
                replacefac = ExtractedFacString(Value);

                fac = Factorial(int.Parse(replacefac));
                ValueCopy = ValueCopy.Replace(replacefac + "!", fac.ToString()); //Replaces Factorial num with the value of that factorial

            }
            return ValueCopy;
        }
        
        public  double Compute(string Value) // Tidy up this method by breakking it up more finely
        {
            string ValueCopy = DoFactorialComputation(Value);//Replaces PI with the actual value

            ValueCopy = RemoveStubSqrt(ValueCopy);
            if (ValueCopy.Contains('(') && ValueCopy.Contains(')'))
            {
                string  tempNew = theBrackets.OutputString;
                string tempOld = theBrackets.OutputStringWithBraces();
                if (ValueCopy.Contains(theBrackets.getEliminationOfBrackets))
                    ValueCopy = ValueCopy.Replace(theBrackets.getEliminationOfBrackets, tempNew);
                else
                ValueCopy = ValueCopy.Replace(tempOld, tempNew);
            }
          
       
            double[] realValues = ExtractAndConvert(ValueCopy);
            double returnValue = 0;
       
            List<double> outputs = new List<double>();
            List<char> characters = Characters(ValueCopy);

            returnValue = FinalOutputHelper(characters, realValues);
            int len = realValues.Length;
          
            return returnValue;
        }

        public override string ToString()
        {
            double val = Compute(this.inputName);
            return val.ToString();
        }
    }
}
