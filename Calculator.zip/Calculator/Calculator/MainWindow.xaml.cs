﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window{
    
        String var = "";

        string VarGet = "";
        Computation compute;
        bool isEqual = false;
        public MainWindow()
        {
            InitializeComponent();
            this.Title = "Calculator App";
            displayBox.BorderBrush = Brushes.Black;
            displayBox.IsReadOnly = true;
         //   compute = new Computation(var);
            
        }

        private void BackSpace_Click(object sender, RoutedEventArgs e)
        {
            displayBox.Text = displayBox.Text.Substring(0, displayBox.Text.Length - 1); // delete one char(last) from the display box
            var = var.Substring(0, var.Length - 1);
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            displayBox.Text = "";
            var = "";
        }

        private void Pi_Click(object sender, RoutedEventArgs e)
        {
            var += "Pi";
            displayBox.Text = var;
        }

        private void one_Click(object sender, RoutedEventArgs e)
        {
            var += 1;
            displayBox.Text = var;
        }

        private void two_Click(object sender, RoutedEventArgs e)
        {
            var += 2;
            displayBox.Text = var;
        }

        private void Three_Click(object sender, RoutedEventArgs e)
        {
            var += 3;
            displayBox.Text = var;
        }

        private void four_Click(object sender, RoutedEventArgs e)
        {
            var += 4;
            displayBox.Text = var;
        }

        private void five_Click(object sender, RoutedEventArgs e)
        {
            var += 5;
            displayBox.Text = var;
        }

        private void six_Click(object sender, RoutedEventArgs e)
        {
            var += 6;
            displayBox.Text = var;
        }

        private void seven_Click(object sender, RoutedEventArgs e)
        {
            var += 7;
            displayBox.Text = var;
        }

        private void eight_Click(object sender, RoutedEventArgs e)
        {
            var += 8;
            displayBox.Text = var;
        }

        private void nine_Click(object sender, RoutedEventArgs e)
        {
            var += 9;
            displayBox.Text = var;
        }

        private void zero_Click(object sender, RoutedEventArgs e)
        {
            var += 0;
            displayBox.Text = var;
        }

        private void Dot_Click(object sender, RoutedEventArgs e)
        {
            var += '.';
            displayBox.Text = var;
        }

        private void equals_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                doThangs();
                isEqual = true;
                if (isEqual) VarGet = var;
            }
            catch (ArgumentException theExc)
            {
                displayBox.Text = "\tError" +theExc.Message;
            }

        }

        private void plus_Click(object sender, RoutedEventArgs e)
        {
            var += '+';
            displayBox.Text = var;
        }

        private void minus_Click(object sender, RoutedEventArgs e)
        {
            var += '-';
            displayBox.Text = var;
        }

        private void divide_Click(object sender, RoutedEventArgs e)
        {
            var += '/';
            displayBox.Text = var;
        }

        private void multiply_Click(object sender, RoutedEventArgs e)
        {
            var += '*';
            displayBox.Text = var;
        }

        private void Sqrt_Click(object sender, RoutedEventArgs e)
        {
            var += "Sqrt";
            displayBox.Text = var;
        }

        private void Testing_Click(object sender, RoutedEventArgs e)
        {
            
            String[] test = { "s6", "s45", "s84", "s69", "s8", "s16" };
            double[] val = { 6, 45, 84, 69, 8, 16 };
          
            double expectedOutCome;
            string temp = "";
            for (int i = 0; i < test.Length; i++)
            {
                compute = new Computation(test[i]);
                expectedOutCome = Math.Sqrt(val[i]);
                temp = Convert.ToString(expectedOutCome);
                if(temp.Length >= 6)
                temp = temp.Substring(0, 3);
                expectedOutCome = Double.Parse(temp);
                Tester.TestEq(compute.Compute(compute.inputName).ToString(), temp);
            }

        }
        int detect = 0;
        private void doThangs()
        {
            compute = new Computation(var);
            displayBox.Text = compute.ToString();
            var = displayBox.Text;
        
        }
        private void Answer_Click(object sender, RoutedEventArgs e)
        {

            var += VarGet;
            displayBox.Text = var;
     

        }

        private void Factorial_Click(object sender, RoutedEventArgs e)
        {
            var += '!';
            displayBox.Text = var;
        }

        private void OpenBracket_Click(object sender, RoutedEventArgs e)
        {
            var += '(';
            displayBox.Text = var;
        }

        private void CloseBracket_Click(object sender, RoutedEventArgs e)
        {
            var += ')';
            displayBox.Text = var;
        }
    }
}
